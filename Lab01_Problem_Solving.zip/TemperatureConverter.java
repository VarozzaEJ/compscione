public class TemperatureConverter {
	
	public static void main(String[] args) {
		// Constant Declarations
		final int BASE;
		final double CONVERSION_FACTOR;
		// Variable Declarations
		double fahrenheitTemp;
		double celsiusTemp;

		// Assignments
		BASE = 32;
		CONVERSION_FACTOR = 9.0 / 5.0;
		celsiusTemp = 24.0; // value to convert

		fahrenheitTemp = celsiusTemp * CONVERSION_FACTOR + BASE;

		System.out.println("Celsius Temperature: " + celsiusTemp);
		System.out.println("Fahrenheit Equivalent: " + fahrenheitTemp);
	}

}
